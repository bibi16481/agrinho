let animal;
let obstacles = [];
let goal;
let level = 1;
let gameState = "start";

function setup() {
  createCanvas(800, 600);
  animal = createVector(50, height / 2);
  goal = createVector(width - 100, height / 2);
  setupObstacles();
}

function draw() {
  background(200, 255, 200);

  if (gameState === "start") {
    showIntro();
  } else if (gameState === "play") {
    playGame();
  } else if (gameState === "win") {
    showWin();
  } else if (gameState === "lose") {
    showLose();
  }
}

function showIntro() {
  background(50, 200, 100);
  fill(255);
  textSize(26);
  textAlign(CENTER);
  text("🌾 Caminho da Sobrevivência 🌿", width / 2, 100);
  textSize(18);
  text("Ajude o animal silvestre a atravessar áreas agrícolas e chegar à floresta!", width / 2, 160);
  text("Use as setas para se mover. Evite tratores e obstáculos agrícolas.", width / 2, 190);
  text("Pressione ENTER para começar.", width / 2, 300);
}

function playGame() {
  // Desenha o habitat e o objetivo
  fill(100, 200, 100);
  rect(0, 0, 100, height); // floresta de origem
  fill(0, 150, 0);
  rect(width - 100, 0, 100, height); // floresta destino

  // Desenha o objetivo
  fill(0, 255, 0);
  ellipse(goal.x, goal.y, 50, 50);

  // Desenha o animal
  fill(120, 60, 20);
  ellipse(animal.x, animal.y, 30, 30);

  moveAnimal();

  // Obstáculos
  for (let obs of obstacles) {
    obs.x += obs.speed;
    if (obs.x > width || obs.x < 0) obs.speed *= -1;
    fill(255, 100, 100);
    rect(obs.x, obs.y, 40, 40);

    // Colisão
    if (dist(animal.x, animal.y, obs.x + 20, obs.y + 20) < 30) {
      gameState = "lose";
    }
  }

  // Vitória
  if (animal.x > goal.x - 25) {
    gameState = "win";
  }
}

function moveAnimal() {
  if (keyIsDown(LEFT_ARROW)) animal.x -= 3;
  if (keyIsDown(RIGHT_ARROW)) animal.x += 3;
  if (keyIsDown(UP_ARROW)) animal.y -= 3;
  if (keyIsDown(DOWN_ARROW)) animal.y += 3;

  animal.x = constrain(animal.x, 0, width);
  animal.y = constrain(animal.y, 0, height);
}

function setupObstacles() {
  obstacles = [];
  for (let i = 0; i < 5 + level * 2; i++) {
    let obs = {
      x: random(150, width - 200),
      y: random(50, height - 50),
      speed: random(1, 3) * (random() > 0.5 ? 1 : -1)
    };
    obstacles.push(obs);
  }
}

function showWin() {
  background(0, 200, 100);
  fill(255);
  textSize(24);
  textAlign(CENTER);
  text("🌳 Você conseguiu! O animal chegou à floresta!", width / 2, height / 2);
  text("Pressione ENTER para continuar para o próximo nível.", width / 2, height / 2 + 40);
}

function showLose() {
  background(200, 50, 50);
  fill(255);
  textSize(24);
  textAlign(CENTER);
  text("💥 Você foi atingido por um trator!", width / 2, height / 2);
  text("Pressione ENTER para tentar novamente.", width / 2, height / 2 + 40);
}

function keyPressed() {
  if (keyCode === ENTER) {
    if (gameState === "start" || gameState === "win") {
      level++;
      animal = createVector(50, height / 2);
      goal = createVector(width - 100, height / 2);
      setupObstacles();
      gameState = "play";
    } else if (gameState === "lose") {
      animal = createVector(50, height / 2);
      setupObstacles();
      gameState = "play";
    }
  }
}
